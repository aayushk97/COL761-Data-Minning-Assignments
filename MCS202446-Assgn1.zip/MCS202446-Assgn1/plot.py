import matplotlib.pyplot as plt
import timeit
import subprocess
import sys

inputfile = sys.argv[1]
supports = [5,10,25,50,90]


ET_ap = []
ET_fp = []
  
for s in supports:
	
	try:
		run_ap = "subprocess.run(\"./apriori "+inputfile+" "+str(s)+" plotOutput\",shell=True, timeout=3600)"
		ET_ap.append(timeit.timeit(run_ap, setup = "import subprocess", number = 1))
	except subprocess.TimeoutExpired as e:
		ET_ap.append(600)
		
	
	try:
		run_fp = "subprocess.run(\"./fpgrowth/fpgrowth/src/fpgrowth -s"+str(s)+" "+inputfile+" plotOutput\",shell=True, timeout=3600)"
		ET_fp.append(timeit.timeit(run_fp, setup = "import subprocess", number = 1))
	except subprocess.TimeoutExpired as e:
		ET_fp.append(600)


plt.figure()
plt.plot(supports, ET_ap, color='#199EF3', marker='o', label='apriori')
plt.plot(supports, ET_fp, color='#FF8c00', marker='o', label='fptree')
plt.title('Execution Time Comparision')
plt.xlabel('Support Threshold')
plt.ylabel('Execution Time (s)')
plt.legend()	
plt.savefig("plot.png")

