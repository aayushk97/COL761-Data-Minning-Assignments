/*		DATA MINING:			ASSIGNMENT 1					*/



I. Explanation of files present:

i. fpgrowth, math tract, util folder used for running of makefile and creation of executable in fpgrowth.
ii. Apriori.cpp : Implementation of Apriori Algorithm.
iii. compile.sh : Bash Script to compile all the programs.
iv. MCS202446: Bash script to run respective programs.
v. plot.py: python script used to run Apriori and FPGrowth and further make graphs.
vi. prefixSpan.cpp prefixSpan.h: Implementation of prefixSpan.
vii. read.cpp: program used to preprocess input data to be used in prefixSpan.
viii. MCS202446_Report.pdf: Explanation of Q2 partb and Desciption on running read.cpp. 
ix. install.sh: commands to load repo and corresponding modules.



II. Explaination of q2-partb

Please check MCS202446_Report.pdf







III. Entry Number and Names of team Members:

i. 2020MCS2444: 	AAYUSH KUMAR SINGH
ii. 2020MCS2446:	AJAY KUMAR SONI
iii. 2020MCS2453:	AYUSH GUPTA
