

#include <bits/stdc++.h>
#include <fstream>

#include <string.h>
#include <string>
#include <vector>
#include <stack>
#include <sstream>

#include "prefixSpan.h"

using namespace std;

int SUPP_THRESHOLD = 1;

vector<string> pattern;

int depth = 0;
void prefixSpan(struct SequenceDatabase* seqData);
map<string, int> buildFreqTable(struct SequenceDatabase* seqDataBase);
struct SequenceDatabase* buildProjectedDatabase(struct SequenceDatabase* seqData, string item);
ofstream outfile;


int main(int argc, char** argv) {
	
	string inpFilename = argv[1];
	int supThresh = stoi(argv[2]);
	string outFilename = argv[3];
	outFilename+=".txt";
	
	
	// //PREPROCESSING BEGINS.
	// ifstream dataFile;
	// vector<string> data;
	// string temp;
	
	// int line=0;
	
	// dataFile.open(inpFilename);
	
	// while(dataFile>>temp) {
    		// string str;
    		// getline(dataFile, str);
		// stringstream buffer(str);
    		
    		// string temp2;
    		// vector<string> values;
		
		// while( getline( buffer, temp2, '\t') ) {
        		// values.push_back(temp2);
    		// }
	
    		// data.push_back(values[3]);
		// values.clear();
	// }
	
	// dataFile.close();
	
	
	// ofstream outfile;
 	// outfile.open("paths_finished.dat");
	
	// for(int i=0;i<data.size();i++){
		// string str=data[i];
		// stringstream buffer(str);
		// string temp;
		// string ans;
		
		// stack<string> use;
		
		// int f=0;
		
		// while(getline(buffer,temp,';')){
			// if(temp!="<"){	
				// ans=ans+temp+" ";
				// use.push(temp);
			// }else{
				// use.pop();
				// ans=ans+use.top()+" ";
			// }
		// }
		
		// outfile<<ans<<endl;
	
	// }
	//PREPROCESSING ENDS
	//Now we read the navigation paths into a data structure.
	string inpLine;
	int item;
	ifstream pDataFile(inpFilename);
	
	int seqId = 0;
	
	struct SequenceDatabase* seqData = new SequenceDatabase();
	
	while(getline(pDataFile, inpLine)){
		struct Sequences* seqLine = new Sequences();
		
		istringstream iss(inpLine);
		string temp = "";
		while(iss >> temp) seqLine -> itemsets.push_back(temp);
		
		seqLine -> seqId = seqId;
		
		seqId++;
		
		seqData -> sequences.push_back(*seqLine);
		seqData -> indices.push_back(0);
		
	}
	
	SUPP_THRESHOLD = ceil(supThresh*0.01*(seqId+1));
	outfile.open(outFilename);

	// for(int i = 0; i < seqData -> sequences.size(); i++){
		
		// cout<<seqData->sequences[i].seqId<<" ";
		
		// for(int j = 0; j < seqData -> sequences[i].itemsets.size(); j++){
			// cout<<seqData -> sequences[i].itemsets[j]<<" ";
		// }
		// cout<<endl;
	
	// }
	
	prefixSpan(seqData);
	pDataFile.close();
	outfile.close();
}	


void prefixSpan(struct SequenceDatabase* seqData){
	
	if(seqData -> sequences.size() < SUPP_THRESHOLD){
		return;
	}
	if(pattern.size()>0){
	for(auto i:pattern)
	{
		outfile<<i<<" ";
	}
	outfile<<endl;
	}
	
	
	map<string, int> freqTable = buildFreqTable(seqData);
	
	
	struct SequenceDatabase* nextSeqData;
	
	for(auto it = freqTable.begin(); it != freqTable.end(); it++){
		pattern.push_back(it -> first);
		
		
		nextSeqData = buildProjectedDatabase(seqData, it -> first);
		
		prefixSpan(nextSeqData);
		
		pattern.pop_back();
		
		//**we clear the nextSeqData
		nextSeqData -> sequences.clear();
		nextSeqData -> indices.clear();
	}
	
}	

struct SequenceDatabase* buildProjectedDatabase(struct SequenceDatabase* seqData, string item){
	
	struct SequenceDatabase* newSeqData = new SequenceDatabase();
	
	for(int i = 0; i < seqData -> sequences.size(); i++){
		Sequences &sequence = seqData -> sequences[i];
		vector<string>& itemsets = sequence.itemsets;
		
		for(int j = seqData -> indices[i]; j < seqData -> sequences[i].itemsets.size(); j++)
		{
			if(seqData -> sequences[i].itemsets[j] == item){
				newSeqData -> sequences.push_back(sequence);
				newSeqData -> indices.push_back(j+1);
				break;
			}
		} 
	
	}

	return newSeqData;
}

map<string, int> buildFreqTable(struct SequenceDatabase* seqDataBase){
	
	map<string, int> freqTable;
	
	for(int i = 0; i < seqDataBase -> sequences.size(); i++){
		for(int j = seqDataBase -> indices[i]; j < seqDataBase -> sequences[i].itemsets.size(); j++){
			freqTable[seqDataBase -> sequences[i].itemsets[j]]++;
		}
	}
	
	
	return freqTable;

}
	
