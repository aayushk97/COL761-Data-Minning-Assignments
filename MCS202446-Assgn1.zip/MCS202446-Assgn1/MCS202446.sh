aprioribin="-apriori";

plotbin="-plot";

prefixspanbin="-prefixspan";

firstarg=$1;
secondarg=$2;
#echo $1
#echo $2
#echo $3
#echo $4
#echo $prefixspanbin
#echo $plotbin
#echo $aprioribin
# Check for plotting

if [ "$secondarg" = "$plotbin" ];
then	
	inputfile=$1
	python3 plot.py $inputfile
elif [ "$firstarg" = "$prefixspanbin" ];
then
	inputfile=$2
	support=$3;
	outputfile=$4;
	./prefixSpan $inputfile $support $outputfile
elif [ "$firstarg" = "$aprioribin" ];
then 
	inputfile=$2
	supportpercent=$3;
	outputfile=$4;
	./apriori $inputfile $supportpercent $outputfile
else

	echo "INPUT FORMAT NOT CORRECT!"
fi
