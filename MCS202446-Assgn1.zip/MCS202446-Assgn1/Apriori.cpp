#include<iostream>
#include<set>
#include<map>
#include<unordered_map>
#include<unordered_set>
#include<vector>
#include<algorithm>
#include<string>
#include<sstream>
#include<fstream>
#include<cmath>
using namespace std;

inline bool subset_check(set<int> itemset, int excluded, vector<vector<int>> frequent_set) {
    itemset.erase(excluded);
    vector<int> s(itemset.begin(),itemset.end());

    bool result = false;
    for(auto x: frequent_set) {
        if (s == x) {
            result = true;
            break;
        }
    }
    return result;
}


map<vector<int>,int> candidate_generate(map<vector<int>,int> F1)
{

	map<vector<int>,int> Ck;

	vector<vector<int>>  frequent_set;

	for(auto x : F1)
	{
		frequent_set.push_back(x.first);
	}


	for(int i = 0;i<frequent_set.size();i++)
	{
		for(int j = i+1;j<frequent_set.size();j++)
		{
			set<int> diff;



			set_difference(frequent_set[j].begin(),frequent_set[j].end(),frequent_set[i].begin(),frequent_set[i].end(),inserter(diff, diff.end()));

			




			if(diff.size() == 1)
			{
				set<int> new_itemset;
				set_union(frequent_set[i].begin(),frequent_set[i].end(),diff.begin(),diff.end(),inserter(new_itemset,new_itemset.end()));


				bool result = true;

				

				 for(auto &excluded : new_itemset) {
                    result = subset_check(new_itemset, excluded, frequent_set);
                    if (result == false) {
                        break;
                    }
                }

				vector<int> itemset(new_itemset.begin(),new_itemset.end());

				if(result == true)
				{
					if(Ck.find(itemset) == Ck.end())
						Ck[itemset] = 0;
				}

			}

		}
	}

	return Ck;
}

int main(int argc, char const *argv[])
{
	



	double support_percent = stod(argv[2]);

	string inputfile = argv[1];
	string outputfile = argv[3];


	unordered_map<int,int> mp;

	long  t_count = 0;

	ifstream inputFile(inputfile);
 

    vector<vector<int>> ans_sets;
	

	if(!inputFile){
		cout<<"unable to open file";
		return 0;
	}

	int item;

	string str;

	while(getline(inputFile,str))
	{
		istringstream  integers(str);
		t_count++;

		while(integers >> item)
		{
	
				mp[item]++;
		}

	}

	map<vector<int>,int> F1;

    int support_threshold = ceil(support_percent*0.01*t_count);


	for(auto x:mp)
	{
	
		if(x.second >= support_threshold)
		{

			F1[{x.first}] = x.second;
		}
	}


	
	


	for(auto x : F1)
	{
		ans_sets.push_back(x.first);
	}


	while(true)
	{

		

		map<vector<int>,int> ck = candidate_generate(F1);

   

		inputFile.clear();
		inputFile.seekg(0, inputFile.beg);




		while(getline(inputFile, str)) 
		{
			istringstream integers(str);

			set<int> transaction;
			int x;
			while(integers >> x)
				transaction.insert(x);

			for(auto cand : ck)
			{

				if(includes(transaction.begin(),transaction.end(),cand.first.begin(),cand.first.end()))
				{
					ck[cand.first]+=1;
				}
			}


		}

	

        
		F1.clear();

		for(auto x:ck)
		{
			
			if(x.second >= support_threshold)
			{

				F1[x.first] = x.second;

			}
		}

        

        if(F1.size() == 0 )
		{
			break;
		}
		else
		{
        for(auto x : F1)
			{
				ans_sets.push_back(x.first);
			}
		}


		



	}


  
  
  ofstream outputFile(outputfile +".txt");
    for(auto x : ans_sets) {

    	vector<string> v;
    	for(int i = 0;i<x.size();i++)
    	{
    		v.push_back(to_string(x[i]));
    	}

        sort(v.begin(),v.end());

        for(auto y : v) {
           
                outputFile << y << " ";
            }
            outputFile << "\n";
        }
    
    outputFile.close();
    inputFile.close();
  
  



	return 0;
}
