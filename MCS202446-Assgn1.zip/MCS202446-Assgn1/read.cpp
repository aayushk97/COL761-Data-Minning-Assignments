#include <fstream>

#include <iostream>

#include <string.h>

#include <string>

#include <vector>

#include <stack>

#include <sstream>

using namespace std;

int main(int argc, char** argv) 

{

int column = stoi(argv[1]);

string inpFile=argv[2];

string outFile=argv[3];

ifstream dataFile;

vector<string> data;

string temp;

int line=0;

dataFile.open(inpFile);

while(dataFile>>temp) {

    std::string str;

    std::getline(dataFile, str);

	//cout<<str;

    std::stringstream buffer(str);

    std::string temp;

    std::vector<string> values;

	//cout<<"HERE\n";

    while( getline( buffer, temp, '\t') ) 

	{

        values.push_back(temp);

    }

	//cout<<values[3]<<line++<<endl;



    data.push_back(values[column]);

	values.clear();

}

//cout<<"HERE2\n";

dataFile.close();

ofstream outfile;

 outfile.open(outFile);

for(int i=0;i<data.size();i++)

{

	string str=data[i];

	stringstream buffer(str);

	string temp;

	string ans;

	stack<string> use;

	int f=0;

	while(getline(buffer,temp,';'))

	{

		if(temp!="<")

		{	

			ans=ans+temp+" ";

			use.push(temp);

		}

		else

		{

			use.pop();

			ans=ans+use.top()+" ";

		}

	}

	outfile<<ans<<endl;

	

}

outfile.close();

}
