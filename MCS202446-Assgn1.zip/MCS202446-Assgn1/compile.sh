#!/bin/bash

g++ -O3 Apriori.cpp -o apriori
g++ read.cpp -o readInput
g++ -O3 prefixSpan.cpp -o prefixSpan
cd fpgrowth/fpgrowth/src
make all  
cd ..
cd ../../


