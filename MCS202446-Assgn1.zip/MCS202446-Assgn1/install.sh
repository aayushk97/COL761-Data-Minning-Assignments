repo="https://github.com/aayushk97/COL761-Data-Minning-Assignments"

git clone "$repo"


file="MCS202446-Assgn1.zip"

unzip "$file"




module load compiler/gcc/7.1.0/compilervars
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
