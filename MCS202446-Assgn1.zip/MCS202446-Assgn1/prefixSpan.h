#include <iostream>
#include <fstream>

#include <string.h>
#include <string>
#include <vector>
#include <stack>
#include <sstream>

using namespace std;

struct Sequences{
	int seqId;
	vector<string> itemsets;	
};

struct SequenceDatabase{
	vector<Sequences> sequences;
	vector<int> indices;
};
