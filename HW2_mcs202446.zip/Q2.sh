#!/bin/bash

firstarg=$1;
secondarg=$2;

cd Q2

rm outputKQueryKD.txt outputKQueryM.txt outputKQueryS.txt

for dim in 2 4 10 20
do
	python3 pca.py $dim $firstarg outputPCA$dim.csv
	python3 q2d.py outputPCA$dim.csv
	python3 q2kdTree.py outputPCA$dim.csv parrot.pkl outputKQueryKD.txt 5 
	python3 main.py outputPCA$dim.csv parrot.pkl outputKQueryM.txt 5
	python3 q2seq.py outputPCA$dim.csv parrot.pkl outputKQueryS.txt 5 
done


python3 plot.py $secondarg
mv $secondarg.png ../
