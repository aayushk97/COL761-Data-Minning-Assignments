firstarg=$1;
secondarg=$2;



cd Q1

g++ script.cpp -o graphminer
./graphminer $firstarg
python3 plot.py $secondarg
mv $secondarg.png ../


