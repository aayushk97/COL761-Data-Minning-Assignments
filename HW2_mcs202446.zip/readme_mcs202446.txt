Instructions:
Step1:run install.sh file

Step2:For Q1 run Q1.sh file. We change the directory to Q1 folder so give relative path accordingly.
e.g:If Input File is present in main folder(HW2_mcs202446) i.e:where Q1.sh resides so command=sh Q1.sh ./../INPUTFILE PLOTNAME

Step3:For Q2 run Q2.sh file. We change the directory to Q2 folder so give relative path accordingly.
e.g:If Input File is present in main folder(HW2_mcs202446) i.e:where Q2.sh resides so command=sh Q2.sh ./../INPUTFILE PLOTNAME

Our output plot will be present in main folder(HW2_mcs202446) after scripts are fully executed for both questions.