import matplotlib.pyplot as plt
import timeit
import subprocess
import sys


plot_name = sys.argv[1]

inputfile1 = "GSPANinput.txt"
inputfile2 = "FSGinput.txt"
supports = [5,10,25,50,90]

total_graphs = 64110
ET_gaston = []
ET_gspan = []
ET_fsg = []
for s in supports:
	
	try:
		run_gaston = "subprocess.run(\"./gaston "+str( (s * total_graphs)/100.0)+" "+inputfile1+" plotOutput\",shell=True,timeout=3600)"
		ET_gaston.append(timeit.timeit(run_gaston, setup = "import subprocess", number = 1))
	except subprocess.TimeoutExpired as e:
		ET_gaston.append(600)
		
	
	try:
		run_gspan = "subprocess.run(\"./gSpan-64 -s"+str(s*1.0/100)+" -f"+inputfile1+" plotOutput\",shell=True,timeout = 3600)"
		ET_gspan.append(timeit.timeit(run_gspan, setup = "import subprocess", number = 1))
	except subprocess.TimeoutExpired as e:
		ET_gspan.append(600)
		
	try:
		run_fsg = "subprocess.run(\"./fsg -s "+str(s)+" "+inputfile2+" plotOutput\",shell=True, timeout=3600)"
		ET_fsg.append(timeit.timeit(run_fsg, setup = "import subprocess", number = 1))
	except subprocess.TimeoutExpired as e:
		ET_fsg.append(600)
		
	


plt.figure()
plt.plot(supports, ET_gspan, color='#199EF3', marker='o', label='Gspan')
plt.plot(supports, ET_fsg, color='#FF8c00', marker='o', label='Fsg')
plt.plot(supports, ET_gaston, color='#458B00', marker='o', label='Gaston')
plt.title('Execution Time Comparision')
plt.xlabel('Support Threshold')
plt.ylabel('Execution Time (s)')
plt.legend()	
plt.grid()
plt.savefig(plot_name+".png")
#plt.show()

