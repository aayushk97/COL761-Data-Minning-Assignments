firstarg=$1;
secondarg=$2;



	

g++ script.cpp -o graphminer
./graphminer $firstarg
python3 plot.py $secondarg


