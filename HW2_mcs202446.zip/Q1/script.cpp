#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <typeinfo>
#include <sstream>
using namespace std;
bool isNumber(string s)
{
    for (int i = 0; i < s.length(); i++)
        if (isdigit(s[i]) == false)
            return false;
 
    return true;
}
int main(int argc, char** argv) 
{

string inpFile=argv[1];
string outFile="FSGinput.txt";
string outFile2="GSPANinput.txt";
ifstream dataFile;
vector<string> data;
string temp;
int line=0;
dataFile.open(inpFile);
ofstream outfile,outfile2;
 outfile.open(outFile);
outfile2.open(outFile2); 
while(getline(dataFile,temp)) 
{
	if(temp=="")
	{
		continue;
	}
	else if(temp[0]=='#')
	{
		outfile<<"t "<<temp[0]<<" "<<temp.substr(1)<<endl;
		outfile2<<"t "<<temp[0]<<" "<<temp.substr(1)<<endl;
		continue;
	}
		int c=stoi(temp);
		//cout<<c<<endl;
		for(int i=0;i<c;i++)
		{
			string str="";
			getline(dataFile,temp);
			int k=int(temp[0])-64;
			//cout<<k<<endl;
			str=str+'v'+' '+to_string(i)+' '+to_string(k);
			outfile<<str<<endl;
			outfile2<<str<<endl;
		}
	getline(dataFile,temp);
	//cout<<"HERE2"<<temp<<endl;
	c=stoi(temp);
	for(int i=0;i<c;i++)
	{
			string str1="",str2="";
			getline(dataFile,temp);
			str1=str1+"u"+" "+temp;
			str2=str2+"e"+" "+temp;
			outfile<<str1<<endl;
			outfile2<<str2<<endl;
	}	
	//cout<<temp<<";"<<isNumber(temp)<<endl;
}
//cout<<"HERE2\n";
dataFile.close();
outfile.close();
outfile2.close();
}
