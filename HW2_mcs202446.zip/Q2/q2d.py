import numpy as np
import sys, re, os
from tqdm.auto import tqdm
import pandas as pd
import random
import pickle

def main():
    #df=pd.read_csv(sys.argv[1],delim_whitespace=True,header=None)
    df=pd.read_csv(sys.argv[1], delim_whitespace=True,header=None)
    print(df)
    df_list = df.values.tolist()
    out_list=[]
    for i in range(100):
        a=random.choice(df_list)
        out_list.append(a)
    with open('parrot.pkl', 'wb') as f:
        pickle.dump(out_list, f)
        
        
    
    

if __name__=="__main__":
    main()
