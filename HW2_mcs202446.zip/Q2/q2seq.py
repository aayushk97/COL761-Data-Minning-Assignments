
import sys, re, os
import numpy as np
import pandas as pd
import pickle
import time
import heapq

def d(x,y):
    x=np.array(x)
    y=np.array(y)
    sq=np.sum(np.square(x-y))
# print(x)
 #   print(y)
  #  print(sq)
    return np.sqrt(sq)

def main():
    df=pd.read_csv(sys.argv[1],delim_whitespace=True,header=None)
    df_list = df.values.tolist()
    #pq={}
    timeList=[]
    
    with open(sys.argv[2], 'rb') as f:
        mynewlist = pickle.load(f)
    
    for j in range(0,len(mynewlist)):
        begin=time.time()
        pq=[]
        for i in range(0,len(df_list)):
            pq.append(d(mynewlist[j],df_list[i]))#pq[i]=d(mynewlist[j],df_list[i])
            #pq=dict(sorted(pq.items(), key=lambda item: item[1]))
            #keys=list(pq.keys())
        
        heapq.heapify(pq)
        
        
        k=int(sys.argv[4])
        
        for i in range(0,k):
            val = heapq.heappop(pq)   
        
        end=time.time()
        pq.clear()
        timeList.append(end-begin)
        
        
    mn=np.mean(timeList)
    sd=np.std(timeList)
    dimension = len(mynewlist[0])
    filename= sys.argv[3]
    
    if os.path.exists(filename):
        append_write = 'a'
    else:
        append_write = 'w'
    


    result_file = open(filename, append_write)
    result_file.write("{},{},{}\n".format(dimension,mn,sd))
    result_file.close()

    
    

if __name__=="__main__":
    main()
    
