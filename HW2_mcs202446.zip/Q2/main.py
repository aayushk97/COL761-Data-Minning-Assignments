from mtree import MTree
import sys, re, os
import numpy as np
from tqdm.auto import tqdm
import pandas as pd
import pickle
import time

def d(x,y):
    x=np.array(x)
    y=np.array(y)
    sq=np.sum(np.square(x-y))
#    print(x)
 #   print(y)
  #  print(sq)
    return np.sqrt(sq)

def main():
    tree=MTree(d);
    df=pd.read_csv(sys.argv[1],delim_whitespace=True,header=None)
    df_list = df.values.tolist()
    for i in range(0,len(df_list)):
        tree.add(df_list[i])
    timeList=[]
    with open(sys.argv[2], 'rb') as f:
        mynewlist = pickle.load(f)
    
    for i in range(0,len(mynewlist)):
        begin=time.time()
        tree.search(mynewlist[i], int(sys.argv[4]))
        end=time.time()
        timeList.append(end-begin)
    mn=np.mean(timeList)
    sd=np.std(timeList)
    dimension = len(mynewlist[0])
    
    filename = sys.argv[3]
    if os.path.exists(filename):
    	append_write = 'a'
    else:
    	append_write = 'w'
    
    result_file = open(filename, append_write)
    result_file.write("{},{},{}\n ".format(dimension,mn,sd))
    result_file.close()
    
    

if __name__=="__main__":
    main()
    
