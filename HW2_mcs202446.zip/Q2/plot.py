
# coding: utf-8

# In[75]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys


# In[76]:

plot_name = sys.argv[1]


df1 = pd.read_csv('outputKQueryKD.txt',header =None , delimiter = ",")


# In[77]:


df2 = pd.read_csv('outputKQueryM.txt',header =None , delimiter = ",")
df3 = pd.read_csv('outputKQueryS.txt',header =None , delimiter = ",")


# In[78]:


kd_tree_meanlist = df1[1].to_list()
mtree_meanlist = df2[1].to_list()
s_meanlist = df3[1].to_list()


# In[79]:


kd_tree_sd = df1[2].to_list()
mtree_sd = df2[2].to_list()
s_sd = df3[2].to_list()


# In[80]:


#get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')


# In[81]:


x = [2, 4, 10 ,20]
dy = kd_tree_sd
y = kd_tree_meanlist


dy1 = mtree_sd
y1 = mtree_meanlist


dy2 = s_sd
y2 = s_meanlist

plt.style.use('seaborn-whitegrid')
#plt.grid()


plt.errorbar(x, y, yerr=dy, fmt='-', color='orange',
             ecolor='blue', elinewidth=2, capsize=5,label='KD Tree');
plt.errorbar(x,y1,yerr =dy1,fmt='-',color='red',ecolor ='blue',elinewidth=2, capsize = 5,label='M Tree')

plt.errorbar(x,y2,yerr =dy2,fmt='-',color='green',ecolor ='blue',elinewidth=2, capsize = 5,label ='Sequential Scan')


plt.title('Execution Time Comparision')
plt.xlabel('Dimensions')
plt.ylabel('Average Execution Time per Query (s)')
plt.legend(frameon = True)
plt.gcf().set_size_inches(10, 6)

plt.savefig(plot_name+".png")
#plt.show()



#plt.show()

