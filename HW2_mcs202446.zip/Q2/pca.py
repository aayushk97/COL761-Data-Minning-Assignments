import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from subprocess import check_output
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

print(check_output(["ls", "./"]).decode("utf8"))

df = pd.read_csv(sys.argv[2], delim_whitespace=True, header=None)

#scale the data between -1 to 1
Scaled_data=StandardScaler().fit_transform(df)

print(df)
#print(Scaled_data)

#set he n components
principal=PCA(n_components=int(sys.argv[1]))

#do scale and transform at once
principalComponents = principal.fit_transform(Scaled_data)
principalDf = pd.DataFrame(data=principalComponents)


#check the dimensions of data after PCA
print(principalDf)
principalDf.to_csv(sys.argv[3], index=False, sep=' ', header=False)


