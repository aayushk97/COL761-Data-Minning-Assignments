import numpy as np 
import pandas as pd
from sklearn.neighbors import KDTree
import pickle
import sys, re, os
import time

df = pd.read_csv(sys.argv[1], delim_whitespace=True, header=None)
df=df.to_numpy()

#print(type(df))
tree = KDTree(df, leaf_size=2)

with open(sys.argv[2], 'rb') as f:
        mynewlist = pickle.load(f)
	
dimension = len(mynewlist[0])
timeList=[]	
for i in range(0,len(mynewlist)):
        begin=time.time()
        #print(mynewlist[i])
        dist, ind = tree.query([mynewlist[i]], k=int(sys.argv[4]))
        end=time.time()
        timeList.append(end-begin)

mn=np.mean(timeList)
sd=np.std(timeList)

filename= sys.argv[3]

if os.path.exists(filename):
	append_write = 'a'
else:
	append_write = 'w'
	


result_file = open(filename, append_write)
result_file.write("{},{},{}\n".format(dimension,mn,sd))
result_file.close()
     


#print(ind)
#print(dist)

